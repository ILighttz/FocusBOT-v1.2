const Discord = require("discord.js");
 
    exports.run = async (client, message) => {
    message.delete();
    const ms = require("ms");
    let messageArray = message.content.split(" ");
    let args = messageArray.slice(1);
    let cmd = messageArray[0];
    const string = '```'
 
     if(cmd === '/mutar'){
            var member = message.mentions.members.first();
            if(member.roles.cache.has("743290475561091163")){ //cargo muted
            let embed = new Discord.MessageEmbed()
            .setColor("#7a297a")
            .setTitle(`**Punições**`) 
            .setDescription(`O usuário @${member.user.tag} já está mutado`)
            .setFooter("Desenvolvido por ILighttz#0002")
            .setTimestamp()
            return message.channel.send(embed);
 
 
      } else 
        if(message.member.hasPermission('MANAGE_MESSAGES')) {
            var member = message.guild.member(message.mentions.users.first() || message.guild.members.cache.get(args[0]));
            if(!member) return message.reply(    
            new Discord.MessageEmbed()
            .setColor("#7a297a")
            .setTitle(`**Punições**`) 
            .setDescription("Nenhum usuario foi informado. /mutar <usario> <tempo> <motivo>")
            .setFooter("Desenvolvido por ILighttz#0002")
            .setTimestamp()
  )                 
            let mainrole = message.guild.roles.cache.find(role => role.name === "Jogadores"); //cargo principal do svr
            let role = message.guild.roles.cache.find(role => role.name === "Muted"); //cargo que vai mutar
 
            if (!role) return message.reply(    
            new Discord.MessageEmbed()
            .setColor("#7a297a")
            .setTitle(`**Punições**`) 
            .addField(`Não existe o cargo ${role} para executar o comando.`, message.author)
            .setFooter("Desenvolvido por ILighttz#0002")
            .setTimestamp()
  )
              var motivo = args.slice(2).join(" ");
              if (!motivo) return message.reply(    
              new Discord.MessageEmbed()
              .setColor("#7a297a")
              .setTitle(`**Punições**`) 
              .addField(`Não foi informado o motivo do Mute`, message.author)
              .setFooter("Desenvolvido por ILighttz#0002")
              .setTimestamp())
 
            let time = args[1];
            if (!time) {
            return message.reply(    
            new Discord.MessageEmbed()
            .setColor("#7a297a")
            .setTitle(`**Punições**`) 
            .addField(`Não foi informado a duração do Mute`, message.author)
            .setFooter("Desenvolvido por ILighttz#0002")
            .setTimestamp()
  );
            }

               message.channel.send(
              new Discord.MessageEmbed()
 
                    .setColor("#7a297a")
                    .setAuthor(message.author.tag, message.author.displayAvatarURL())
                    .setDescription(`Punição aplicada com sucesso no usuário ${member}, verifique os registros de auditoria em <#743305780039778334>`)
                    .setTimestamp());
 
            member.roles.add("743290475561091163");
 
            var canal = message.guild.channels.cache.find(ch => ch.id === "743305780039778334"); //canal que vai mandar as logs
                    const msg = canal.send(    
                    new Discord.MessageEmbed()
 
                    .setColor("#7a297a")
                    .setAuthor(member.user.tag, member.user.displayAvatarURL())
                    .setTitle(`**Punição**`) 
                    .setDescription(`Punição: Mute\nDuração: ${time}\n\n${motivo}` )
                    .setFooter(`Punição feita por ${message.author.tag}`,message.author.displayAvatarURL())
                    .setTimestamp());
            setTimeout( function () {
                member.roles.remove("743290475561091163");
                canal.send(    
            new Discord.MessageEmbed()
            .setColor("#7a297a")
            .setAuthor(message.author.tag, message.author.displayAvatarURL())
            .setTitle(`**Punições - Auditoria**`) 
            .setDescription(`O usuário @${member} foi desmutado AUTOMATICAMENTE`)
            .setFooter("Desenvolvido por ILighttz#0002")
            .setTimestamp()
  )
            }, ms(time));
        } else {
            return message.channel.send(    
            new Discord.MessageEmbed()
            .setColor("#7a297a")
            .setDescription(`Sem permissão`))
        }
    }
    }
 
exports.help = {
    name: 'mute'
}