const Discord = require('discord.js')

exports.run = (bot,message,args) => {
  let embed = new Discord.MessageEmbed()

   .setColor('#7a297a')
   .setTitle(`Informações do BOT`) 
   .setDescription(`**Informação**\nEste bot tem como função ajuda em moderação do discord e diversão!\n\n**PING**\nLatencia do BOT: **${Math.round(bot.ws.ping)}ms**\n`)
   .setThumbnail('https://media.giphy.com/media/ZCT8H9esimXQFOTs2t/giphy.gif')
   .setFooter('Desenvolvido por ILighttz#0002')
   .setTimestamp();

  message.channel.send(embed);
}
