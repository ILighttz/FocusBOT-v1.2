const Discord = require('discord.js')

      exports.run = (bot, message, args) => {
        message.delete();
        let messageArray = message.content.split(" ");
        let cmd = messageArray[0];
        if(cmd === '/desmutar'){
            var member = message.mentions.members.first();
            if(!member.roles.cache.has("743290475561091163")){ //cargo muted
            let embed = new Discord.MessageEmbed()
            .setColor("#7a297a")
            .setTitle(`**Punições**`) 
            .setDescription(`O usuário @${member.user.tag} não está mutado`)
            .setFooter("Desenvolvido por ILighttz#0002")
            .setTimestamp()
            return message.channel.send(embed);
 
 
      } else if(message.member.hasPermission('MANAGE_MESSAGES')) {
            var member = message.guild.member(message.mentions.users.first() || message.guild.members.cache.get(args[0]));
            if(!member) return message.reply(    
            new Discord.MessageEmbed()
            .setColor("#7a297a")
            .setTitle(`**Punições**`) 
            .setDescription("O usuário não está no cargo principal.")
            .setFooter("Desenvolvido por ILighttz#0002")
            .setTimestamp()
  )     
            member.roles.remove("743290475561091163")
            member.roles.add("743236406515859598");

             message.channel.send(
                    new Discord.MessageEmbed()
 
                    .setColor("#7a297a")
                    .setAuthor(message.author.tag, message.author.displayAvatarURL())
                    .setDescription(`Punição revogada com sucesso no usuário ${member}, verifique os registros de auditoria em <#743305780039778334>`)
                    .setTimestamp());

            var canal = message.guild.channels.cache.find(ch => ch.id === "743305780039778334"); //canal que vai mandar as logs
                    const msg = canal.send(    
                    new Discord.MessageEmbed()
 
                    .setColor("#7a297a")
                    .setAuthor(member.user.tag, member.user.displayAvatarURL())
                    .setTitle(`**Punição**`) 
                    .setDescription(`Mute removido`)
                    .setFooter(`Revogação feita por ${message.author.tag}`)
                    .setTimestamp())

        } else {
            return message.channel.send(    
            new Discord.MessageEmbed()
            .setColor("#7a297a")
            .setDescription(`Sem premissão`)
            .setFooter("Desenvolvido por ILighttz#0002")
            .setTimestamp())
        }
        }
      }
        