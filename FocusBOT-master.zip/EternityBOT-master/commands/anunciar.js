const Discord = require('discord.js')

exports.run = (bot,message,args) => {
message.delete();
  let embed = new Discord.MessageEmbed()

   .setColor('#7a297a')
   .setTitle(`Anuncio`) 
   .setDescription(`Crie o anuncio por: https://discord.club/embedg/`)
   .setThumbnail('https://media.giphy.com/media/ZCT8H9esimXQFOTs2t/giphy.gif')
   .setFooter('Desenvolvido por ILighttz#0002')
   .setTimestamp();

  message.channel.send(embed);
}
