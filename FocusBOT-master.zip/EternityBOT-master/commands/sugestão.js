const Discord = require("discord.js");

exports.run = async (client, message, args) => {
message.delete();
const content = args.join(" ");

if (!args[0]) {
  return message.channel.send(    
    new Discord.MessageEmbed()
    .setColor("#7a297a")
    .setTitle(`**Sugestões**`) 
    .addField(`Escreva a sugestão após o comando. /sugestão <texto>,`, message.author)
    .setFooter("Desenvolvido por ILighttz#0002")
    .setTimestamp()
  ).then(msg => msg.delete({timeout: 10000}))
} else if (content.length > 1000) {
  return message.channel.send(    
    new Discord.MessageEmbed()
    .setColor("#7a297a")
    .setTitle(`**Sugestões**`) 
    .addField(`A sugestão não pode ter mais que 1000 caracteres`, message.author)
    .setFooter("Desenvolvido por ILighttz#0002")
    .setTimestamp()
  ).then(msg => msg.delete({timeout: 10000}));
} else {
  var canal = message.guild.channels.cache.find(ch => ch.id === "743306404357472267");
  const string = '```'
  const msg = await canal.send(
    new Discord.MessageEmbed()
    .setColor("#7a297a")
    .setTitle(`**Sugestão**`) 
    .setDescription(`**Autor:** ${message.author}`)
    .addField("Sugestão:", string + content + string)
    .setThumbnail('https://media.giphy.com/media/ZCT8H9esimXQFOTs2t/giphy.gif')
    .setFooter("Avaliem essa sugestão com as reações!")
    .setTimestamp()
  );
  await message.channel.send(    
    new Discord.MessageEmbed()
    .setColor("#7a297a")
    .setDescription(`${message.author} Sua sugestão foi enviada com sucesso`)
    .setFooter("Desenvolvido por ILighttz#0002")
    .setTimestamp()
  ).then(msg => msg.delete({timeout: 10000}));

  const emojis = ["✅", "❌"];

  for (const i in emojis) {
    await msg.react(emojis[i])
  }
}
}