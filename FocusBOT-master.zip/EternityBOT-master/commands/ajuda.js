const Discord = require('discord.js')

exports.run = (bot,message,args) => {
  let embed = new Discord.MessageEmbed()

   .setColor('#7a297a')
   .setTitle(`Informações do BOT`) 
   .setDescription(`**Olá meu nome é Untitle, sou um BOT da moderação e auxilio. O meu prefix é "/" e aqui você podera ver todos os meus comandos!**\n\n**COMANDOS**\n**/ajuda** → Forneço informações e ajuda.\n**/info** → Veja os status do BOT\n**/sugestão** → Faça uma sugestão no Discord\n**/ping** → Veja o ping do servidor e bot\n**/limpar** → Limpe as ultimas mensagens no chat\n**/avatar** → Consiga o avatar de um usuário\n**/banir** → Faça o banimento de um jogador\n**/expulsar** → Expulse um jogador\n**/mutar** → Mute um jogador temporariamente\n**/desmutar** → Desmute um jogador\n\n**Mais comandos a serem desenvolvidos, aguarde por atualizações**`  )
   .setThumbnail('https://media.giphy.com/media/ZCT8H9esimXQFOTs2t/giphy.gif')
   .setFooter('Desenvolvido por ILighttz#0002', bot.user.displayAvatarURL)
   .setTimestamp();

  message.channel.send(embed);
}