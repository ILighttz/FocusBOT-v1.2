const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {
  let embed = new Discord.MessageEmbed()

   .setColor('#7a297a')
   .setTitle(`Latencia Geral`) 
   .setDescription(`Latência da API: **${Math.round(client.ws.ping)}ms**`)
   .setThumbnail('https://media.giphy.com/media/ZCT8H9esimXQFOTs2t/giphy.gif')
   .setFooter('Desenvolvido por ILighttz#0002')
   .setTimestamp();

  message.channel.send(embed);
};

