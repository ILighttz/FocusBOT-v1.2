const Discord = require('discord.js')

exports.run = (client,message,args) => {
  let guild = client.guilds.cache.get("455876189060464641");
  let embed = new Discord.MessageEmbed()
   .setColor('#7a297a')
   .setTitle(`MEMBROS NO SERVIDOR`)
   .setDescription(`Olá,${message.author} o servidor conta com membros totais e `)
   .setFooter('Desenvolvido por ILighttz#0002', message.author)
   .setTimestamp()

  message.channel.send(embed);
};

