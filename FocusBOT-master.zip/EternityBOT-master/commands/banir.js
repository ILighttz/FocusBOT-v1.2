const Discord = require("discord.js");
 
exports.run = (bot, message, args) => {
 
    var membro = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!membro) return message.reply(    
    new Discord.MessageEmbed()
    .setColor("#7a297a")
    .setTitle(`**Punições**`) 
    .addField(`Necessário mencionar um usuario. /banir <@usuario> <motivo>`, message.author)
    .setFooter("Desenvolvido por ILighttz#0002")
    .setTimestamp())
    if (membro === message.member) return message.reply(    
    new Discord.MessageEmbed()
    .setColor("#7a297a")
    .setTitle(`**Punições**`) 
    .addField(`Você não pode punir você mesmo!`, message.author)
    .setFooter("Desenvolvido por ILighttz#0002")
    .setTimestamp())
 
    var motivo = args.slice(1).join(" ");
    if (!motivo) return message.reply(    
    new Discord.MessageEmbed()
    .setColor("#7a297a")
    .setTitle(`**Punições**`) 
    .addField(`Nececssário colocar o motivo. /banir <@usuario> <motivo>`, message.author)
    .setFooter("Desenvolvido por ILighttz#0002")
    .setTimestamp())
    
    if (!message.member.hasPermission("BAN_MEMBERS")) return message.reply(    
    new Discord.MessageEmbed()
            .setColor("#7a297a")
            .setDescription(`Sem premissão`)
            .setFooter("Desenvolvido por ILighttz#0002")
            .setTimestamp())

 
      var canal = message.guild.channels.cache.find(ch => ch.id === "743305780039778334");
 
    message.channel.send(    
    new Discord.MessageEmbed()
    .setColor("#7a297a")
    .setTitle(`**Punições**`) 
    .addField(`Você realmente deseja punir este jogador?`, message.author)
    .setFooter("Desenvolvido por ILighttz#0002")
    .setTimestamp()).then(msg => {
        msg.react("👍")
 
        let filtro = (reaction, usuario) => reaction.emoji.name === "👍" && usuario.id === message.author.id;
        let coletor = msg.createReactionCollector(filtro, {max: 1})
 
        coletor.on("collect", cp => {
            cp.remove(message.author.id);
        const msg = canal.send(    
    new Discord.MessageEmbed()
    .setColor("#7a297a")
    .setTitle(`**Punições**`) 
    .addField(`Foi banido o jogador: `, membro.user.username)
    .addField(`Pelo motivo: `, motivo)
    .setFooter("Desenvolvido por ILighttz#0002")
    .setTimestamp())
            membro.ban();
        })
    })
}
 
exports.help = {
    name: 'ban'
}